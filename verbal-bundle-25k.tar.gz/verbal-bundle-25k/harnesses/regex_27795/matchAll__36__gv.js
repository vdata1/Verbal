// provenance:
//   git_commit: a3d8db9b0c02f1a9ab61e04f5a204bfcac84b798-dirty
//   config_sha: b0e31920351c56cfbeaf3ad889e5df602083232372af52fed8b81a9b9682caf4
//   seed: 0
//   corpus: data/uniq-regexes-8.json
//   corpus_sha: 999fe71e83f0db26931d6810164bff9efefdf3f6791d3444aa770ccdafe280e9
//   chunk_start: 27700
//   chunk_count: 100
//   stage: harness
//   api: matchAll
//   regex_id: regex_27795
//   flags: gv
"use strict";
const pattern = "(?:[^\\\\]|\\\\.)*[^\\\\]\\$[a-zA-Z_\\x7f-\\uffff][a-zA-Z0-9_\\x7f-\\uffff]*";
const flags = "gv";
const input = "\n\\^\\V_\\\u0013cD$\u2a12\u706a\u5189\u25c6\u2820\u7700\u5e6d\u5e6d\u3553\u9212\u3621\uab74\u7d9d\n!\\ O\\\u007f\\MkW1$\\h41(lL=\\.9$\u4727\u1591\udf8a\u093c\ucde8\ufae2\uddb5\u886a\u9834\u2cd4\uacb3\ud623\u13c0\u5161\u49d5\ud9b3\u42b3\u6b69\n";
const api = "matchAll";
const regex_id = "regex_27795";

function enc(x) {
  if (x === undefined) return {"__undef__": true};
  if (Array.isArray(x)) return x.map(enc);
  return x;
}
function serializeMatch(m) {
  if (m === null) return null;
  const out = {match: m[0], groups: Array.prototype.slice.call(m, 1).map(enc), index: m.index};
  if (m.groups) {
    const named = {};
    for (const k of Object.keys(m.groups).sort()) named[k] = enc(m.groups[k]);
    out.named = named;
  }
  // `.indices` exists ONLY under the `d` (hasIndices) flag -- a [start,end] span per
  // group (undefined for a non-participating one, hence enc). Guarded so a non-`d`
  // match serializes byte-for-byte as before: this axis is pure new signal, catching
  // engines that return the same matched string from a different span.
  if (m.indices) {
    out.indices = Array.prototype.slice.call(m.indices).map(enc);
    if (m.indices.groups) {
      const ig = {};
      for (const k of Object.keys(m.indices.groups).sort()) ig[k] = enc(m.indices.groups[k]);
      out.indices_named = ig;
    }
  }
  return out;
}

// lastIndex preset battery (rationale: api_descriptors._LASTINDEX_PRESETS_JS).
function lastIndexPresets(s) {
  const seen = new Set(), out = [];
  for (const k of [0, 1, Math.floor(s.length / 2), s.length, s.length + 1]) { if (!seen.has(k)) { seen.add(k); out.push(k); } }
  return out;
}
function presetBattery(re, s, call) {
  if (!re.global && !re.sticky) return call();   // lastIndex dead -> value unchanged
  const out = {};
  for (const k of lastIndexPresets(s)) {
    re.lastIndex = k;
    out["preset_" + k] = {result: call(), lastIndex: re.lastIndex};
  }
  re.lastIndex = 0;
  return out;
}

try {
  const re = new RegExp(pattern, flags);
  let value;
  const t0 = performance.now();
  value = presetBattery(re, input, () => Array.from(input.matchAll(re)).map(serializeMatch));
  const t1 = performance.now();
  process.stdout.write(JSON.stringify({api: api, regex_id: regex_id, ok: true, value: value, exec_ms: t1 - t0}) + "\n");
} catch (e) {
  process.stdout.write(JSON.stringify({api: api, regex_id: regex_id, ok: false, error: (e && e.name) || String(e)}) + "\n");
}
