// provenance:
//   git_commit: e5254ad6f1559fa6a8ba2f36ff7878b0c9d578b6-dirty
//   config_sha: b0e31920351c56cfbeaf3ad889e5df602083232372af52fed8b81a9b9682caf4
//   seed: 0
//   corpus: data/uniq-regexes-8.json
//   corpus_sha: 999fe71e83f0db26931d6810164bff9efefdf3f6791d3444aa770ccdafe280e9
//   chunk_start: 31000
//   chunk_count: 100
//   stage: harness
//   api: exec
//   regex_id: regex_31045
//   flags: gu
"use strict";
const pattern = "\\p{Lu}+(?!\\p{Ll})|\\p{Lu}";
const flags = "gu";
const input = "\ud83a\udd0b\ud801\udd86\ud835\udcab\u1e46B\u0003\u0000U\u0010=r}\u001f4Ib/B!\u0014d";
const api = "exec";
const regex_id = "regex_31045";

function enc(x) {
  if (x === undefined) return {"__undef__": true};
  if (Array.isArray(x)) return x.map(enc);
  return x;
}
function serializeMatch(m) {
  if (m === null) return null;
  const out = {match: m[0], groups: Array.prototype.slice.call(m, 1).map(enc), index: m.index};
  if (m.groups) {
    const named = {};
    for (const k of Object.keys(m.groups).sort()) named[k] = enc(m.groups[k]);
    out.named = named;
  }
  // `.indices` exists ONLY under the `d` (hasIndices) flag -- a [start,end] span per
  // group (undefined for a non-participating one, hence enc). Guarded so a non-`d`
  // match serializes byte-for-byte as before: this axis is pure new signal, catching
  // engines that return the same matched string from a different span.
  if (m.indices) {
    out.indices = Array.prototype.slice.call(m.indices).map(enc);
    if (m.indices.groups) {
      const ig = {};
      for (const k of Object.keys(m.indices.groups).sort()) ig[k] = enc(m.indices.groups[k]);
      out.indices_named = ig;
    }
  }
  return out;
}

// lastIndex preset battery (rationale: api_descriptors._LASTINDEX_PRESETS_JS).
function lastIndexPresets(s) {
  const seen = new Set(), out = [];
  for (const k of [0, 1, Math.floor(s.length / 2), s.length, s.length + 1]) { if (!seen.has(k)) { seen.add(k); out.push(k); } }
  return out;
}
function presetBattery(re, s, call) {
  if (!re.global && !re.sticky) return call();   // lastIndex dead -> value unchanged
  const out = {};
  for (const k of lastIndexPresets(s)) {
    re.lastIndex = k;
    out["preset_" + k] = {result: call(), lastIndex: re.lastIndex};
  }
  re.lastIndex = 0;
  return out;
}

try {
  const re = new RegExp(pattern, flags);
  let value;
  const t0 = performance.now();
  value = presetBattery(re, input, () => serializeMatch(re.exec(input)));
  const t1 = performance.now();
  process.stdout.write(JSON.stringify({api: api, regex_id: regex_id, ok: true, value: value, exec_ms: t1 - t0}) + "\n");
} catch (e) {
  process.stdout.write(JSON.stringify({api: api, regex_id: regex_id, ok: false, error: (e && e.name) || String(e)}) + "\n");
}
