Verbal ReDoS bundle
===================

Collected by collect_redos.py v1.0 from
/home/abdullah/verbal/results

Windows:
  0_1500         confirmed  queued=0      confirmed=250

Confirmed rows:   250 (250 shipped with input+harness)
Queued nominees:  0
Distinct regexes: 3
Harnesses copied: 250
Per-regex cap:    none (all rows shipped)

CONTENTS
  MANIFEST.json   windows, kind, engine versions, provenance, tallies, misses.
                  START HERE, and read `kind` before reading any number below it.
  by_regex.json   confirmed rows folded to (regex_id, api) with the worst serial time.
                  A handful of patterns account for hundreds of rows.
  rows.jsonl      one object per shipped confirmed row: the verdict fields verbatim,
                  plus the input string that produced it and the harness path.
  redos_<window>.json         the verdict artifact, verbatim.
  redos_queue_<window>.json   the nominations, verbatim. Entries embed harness_source,
                              so a deferred window can be confirmed on the far end.
  harnesses/      the exact .js executed, as <regex_id>/<api>__<n>__<flags>.js

READ THIS BEFORE QUOTING ANY COUNT
  1. kind=deferred means NOTHING in that window is a result. Queue timings were taken
     under load, with an unknown inflation factor. Confirm serially on a quiet box:
         python3 eval/confirm_redos.py --queue redos_queue_<window>.json
  2. Use serial_ms, never pool_ms.
  3. `engine_specific` is NOT a finding count. A timed-out engine is scored at the
     harness budget, so ratio = budget / fastest and the gate collapses into a threshold
     on the FAST engine. If MANIFEST reports split_fields_present=false, run
     analysis/eval_help_scripts/backfill_ratio_split.py before reading it; if true, read
     engine_specific_measured (two-sided) apart from engine_specific_lower_bound.
  4. is_lower_bound=true means the row was killed while still backtracking: the true
     cost is worse than recorded.
  5. confirmed != ReDoS. These are unrelated fuzz strings at one length, so nothing here
     measured superlinear growth. Only a growing-length family separates an algorithmic
     class from a constant factor -- see redos_nomination/growth_family.py.
  6. node and deno are both V8 and agree within ~1.2x wherever both were measured;
     slowest_engine flipping between them is scheduling noise, not a differential.

  Strings are ASCII-escaped (\udXXX): corpus inputs contain lone surrogates on purpose.
  json.loads restores them; re-encoding to UTF-8 will raise.

  ENGINE VERSIONS MATTER. Timings are only comparable at the versions in MANIFEST.json.
