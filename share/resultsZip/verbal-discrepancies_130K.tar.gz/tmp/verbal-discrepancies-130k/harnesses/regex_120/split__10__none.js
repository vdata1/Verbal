// provenance:
//   git_commit: 39654b7460704be57cbd99ba9ff7b208a76c265b-dirty
//   config_sha: ceab86e216eeb5c32e8c5e4c49aa45949c668b6afa47ea2bca72498c111c6381
//   seed: 0
//   corpus: data/uniq-regexes-sample-3000.json
//   corpus_sha: f0978d1fa48649748e3072cb562ed7f562754444a250ee22149928fd63f2b8ba
//   chunk_start: 100
//   chunk_count: 100
//   stage: harness
//   api: split
//   regex_id: regex_120
//   flags: (none)
"use strict";
const pattern = ".*/lookup\\b.*";
const flags = "";
const input = "8!{\u0001+{gO;7</?/lookup\\Ac\u0002\u0005s\u000fqN";
const api = "split";
const regex_id = "regex_120";

function enc(x) {
  if (x === undefined) return {"__undef__": true};
  if (Array.isArray(x)) return x.map(enc);
  return x;
}
function serializeMatch(m) {
  if (m === null) return null;
  const out = {match: m[0], groups: Array.prototype.slice.call(m, 1).map(enc), index: m.index};
  if (m.groups) {
    const named = {};
    for (const k of Object.keys(m.groups).sort()) named[k] = enc(m.groups[k]);
    out.named = named;
  }
  // `.indices` exists ONLY under the `d` (hasIndices) flag -- a [start,end] span per
  // group (undefined for a non-participating one, hence enc). Guarded so a non-`d`
  // match serializes byte-for-byte as before: this axis is pure new signal, catching
  // engines that return the same matched string from a different span.
  if (m.indices) {
    out.indices = Array.prototype.slice.call(m.indices).map(enc);
    if (m.indices.groups) {
      const ig = {};
      for (const k of Object.keys(m.indices.groups).sort()) ig[k] = enc(m.indices.groups[k]);
      out.indices_named = ig;
    }
  }
  return out;
}

// lastIndex preset battery (rationale: api_descriptors._LASTINDEX_PRESETS_JS).
function lastIndexPresets(s) {
  const seen = new Set(), out = [];
  for (const k of [0, 1, Math.floor(s.length / 2), s.length, s.length + 1]) { if (!seen.has(k)) { seen.add(k); out.push(k); } }
  return out;
}
function presetBattery(re, s, call) {
  if (!re.global && !re.sticky) return call();   // lastIndex dead -> value unchanged
  const out = {};
  for (const k of lastIndexPresets(s)) {
    re.lastIndex = k;
    out["preset_" + k] = {result: call(), lastIndex: re.lastIndex};
  }
  re.lastIndex = 0;
  return out;
}

try {
  const re = new RegExp(pattern, flags);
  let value;
  const t0 = performance.now();
  value = {default: input.split(re).map(enc)};
  for (const L of [undefined, 0, 1, 1000000, -1, 2**32, 2**32 - 1, 1.5, NaN, "2"]) { value['limit_' + String(L)] = input.split(re, L).map(enc); }
  const t1 = performance.now();
  process.stdout.write(JSON.stringify({api: api, regex_id: regex_id, ok: true, value: value, exec_ms: t1 - t0}) + "\n");
} catch (e) {
  process.stdout.write(JSON.stringify({api: api, regex_id: regex_id, ok: false, error: (e && e.name) || String(e)}) + "\n");
}
