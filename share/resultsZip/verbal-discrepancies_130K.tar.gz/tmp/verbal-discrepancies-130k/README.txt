Verbal discrepancy bundle
=========================

Collected by collect_discrepancies.py v1.0 from
/home/abdullah/verbal/results

Windows:            0_1500
Discrepant cells:   582 reported, 582 shipped
Clusters:           18
Harnesses copied:   582
Per-cluster cap:    none (all cells shipped)

CONTENTS
  MANIFEST.json   windows, engine versions, provenance, counts, and any misses
  clusters.json   cells grouped by (regex_id, api, engine partition), biggest first.
                  START HERE -- one engine fact books hundreds of cells, so the
                  cluster count is much closer to a bug count than the cell count.
  evidence.jsonl  one object per shipped cell: the full diff case (per-engine exit,
                  timed_out, stdout/stderr, canonical, comparable), the input string
                  that produced it, and the path to the harness.
  harnesses/      the exact .js executed, as <regex_id>/<api>__<n>__<flags>.js
  eval_headline_<window>.json   copied verbatim; the provenance anchor.

REPRODUCING A CASE
  Run the harness with the matching engine. It reproduces the recorded result by
  construction -- do NOT hand-write a snippet from the pattern alone. Under g/y the
  harness sweeps a lastIndex preset battery, so a divergence at preset_k does not
  reproduce from a bare call, which starts at lastIndex 0.

      node harnesses/<regex_id>/<api>__<n>__<flags>.js
      bun  harnesses/<regex_id>/<api>__<n>__<flags>.js
      deno run --quiet harnesses/<regex_id>/<api>__<n>__<flags>.js

  ENGINE VERSIONS MATTER. Results are only comparable at the versions recorded in
  MANIFEST.json; different node/bun/deno versions legitimately produce different
  artifacts. Check before concluding anything about a mismatch.

READING IT
  python3 - <<'EOF'
  import json
  for line in open('evidence.jsonl'):
      e = json.loads(line)
      print(e['regex_id'], e['api'], '#%d' % e['n'],
            '[%s]' % (e['flags'] or 'none'), e['engine_partition'])
  EOF

  Strings are ASCII-escaped (\udXXX): corpus inputs contain lone surrogates on
  purpose. json.loads restores them; re-encoding to UTF-8 will raise.

CAVEATS
  - Cell counts are not bug counts. clusters.json is the honest view, and even it
    reports one bug once per corpus witness; reduce.py collapses further.
  - node and deno are both V8, so a node,deno|bun partition is one implementation
    disagreeing with one other, not a 2-vs-1 majority.
  - A partition with a leading '!' group (e.g. "node,deno|!bun") means that engine
    produced no comparable value at all -- a defect or a timeout, not a differing
    value. Check `case.runs.<engine>.timed_out` before calling it a discrepancy.
